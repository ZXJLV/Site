create
    definer = root@localhost procedure proc_checkitem_patients(IN item_name varchar(100))
BEGIN
	SELECT patientName FROM patient WHERE patientID IN(
		SELECT patientID FROM prescription WHERE checkItemID IN(
			SELECT checkItemID FROM checkitem WHERE checkItemName LIKE CONCAT('%',item_name,'%')));
END;

