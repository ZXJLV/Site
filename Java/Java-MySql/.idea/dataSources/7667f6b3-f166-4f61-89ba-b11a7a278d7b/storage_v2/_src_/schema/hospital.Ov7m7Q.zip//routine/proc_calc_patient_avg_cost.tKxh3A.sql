create
    definer = root@localhost procedure proc_calc_patient_avg_cost(IN p_patientID int, OUT avg_cost double)
BEGIN
  DECLARE t_totalcost FLOAT; #病人总的医疗费用
	DECLARE t_visit_count INT; #病人来看病的次数
	#根据病人编号统计病人总的医疗费用和看病次数并将结果报错到局部变量中
	SELECT SUM(checkItemCost) INTO t_totalcost FROM prescription p1 INNER JOIN checkitem ON p1.checkItemID = checkitem.checkItemID WHERE patientID = p_patientID;
	SELECT COUNT(DISTINCT examDate) INTO t_visit_count FROM prescription WHERE patientID = p_patientID;
	#计算病人每次就医的平均费用
	SET avg_cost = t_totalcost/t_visit_count;
END;

