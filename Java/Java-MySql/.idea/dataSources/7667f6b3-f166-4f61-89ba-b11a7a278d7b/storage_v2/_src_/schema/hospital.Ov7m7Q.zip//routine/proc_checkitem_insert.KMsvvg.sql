create
    definer = root@localhost procedure proc_checkitem_insert(IN checkitems varchar(100))
BEGIN
 	DECLARE comma_pos INT;
  DECLARE current_checkitem VARCHAR(20);
	loop_label: LOOP
		SET comma_pos = LOCATE(',', checkitems);
		SET current_checkitem = SUBSTR(checkitems, 1, comma_pos-1);
		IF current_checkitem <> '' THEN
			SET checkitems = SUBSTR(checkitems, comma_pos+1);
    ELSE
      SET current_checkitem = checkitems;
    END IF;
    INSERT INTO checkitem(checkItemName,checkItemCost) VALUES(current_checkitem,70);
		IF comma_pos=0 OR current_checkitem='' THEN
      LEAVE loop_label;
    END IF;
	END LOOP loop_label;
END;

