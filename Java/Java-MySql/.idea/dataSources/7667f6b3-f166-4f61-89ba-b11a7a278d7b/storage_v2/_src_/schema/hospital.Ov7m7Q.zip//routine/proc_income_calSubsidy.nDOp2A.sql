create
    definer = root@localhost procedure proc_income_calSubsidy(IN i_patientID int, IN i_year varchar(10), OUT o_subsidy float)
BEGIN
	DECLARE t_totalCost Float;
	DECLARE t_income Float DEFAULT -1;
	SELECT SUM(checkItemCost) INTO t_totalCost FROM prescription p1 INNER JOIN checkitem ON p1.checkItemID = checkitem.checkItemID 
WHERE patientID = 1 AND examDate >= CONCAT(i_year,'-01-01') AND examDate <= CONCAT(i_year,'-12-31');
	SELECT income INTO t_income FROM subsidy WHERE patientID = i_patientID;
#根据规则计算返还金额
	CASE 
		WHEN t_income >=0 AND t_income < 5000 THEN SET o_subsidy = t_totalCost * 0.2;
		WHEN t_income < 1000 THEN SET o_subsidy = t_totalCost * 0.15;
		WHEN t_income < 30000 THEN SET o_subsidy = t_totalCost * 0.05;
		WHEN t_income >= 30000 OR t_income < 0 THEN SET o_subsidy = 0;
	END CASE;
END;

