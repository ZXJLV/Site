create
    definer = root@localhost procedure proc_exam_GetLastExamDateByPatientNameAndDepID(IN patient_name varchar(50),
                                                                                      IN dep_id int,
                                                                                      OUT last_exam_date datetime)
BEGIN
	#Routine body goes here...
  DECLARE patient_id INT;  #声明局部变量
  SELECT patientID INTO patient_id FROM patient WHERE patientName= patient_name;
  SELECT patient_id; #输出病人的ID
  SELECT MAX(examDate) INTO last_exam_date FROM prescription WHERE patientID = patient_id AND depID = dep_id;
END;

