create
    definer = root@localhost procedure proc_patient_countPatient2(OUT patientNum int)
BEGIN
SELECT COUNT(*) INTO patientNum FROM patient;
END;

