create
    definer = root@localhost procedure proc1()
BEGIN
  SET @name = '王明';
END;

