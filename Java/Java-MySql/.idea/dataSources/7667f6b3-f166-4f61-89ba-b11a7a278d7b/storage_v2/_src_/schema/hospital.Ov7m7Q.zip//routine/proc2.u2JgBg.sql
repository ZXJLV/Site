create
    definer = root@localhost procedure proc2()
BEGIN
   SELECT CONCAT('name:',@name);
END;

