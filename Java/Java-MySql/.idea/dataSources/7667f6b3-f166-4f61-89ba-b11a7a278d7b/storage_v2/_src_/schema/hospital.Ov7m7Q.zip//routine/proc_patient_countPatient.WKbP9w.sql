create
    definer = root@localhost procedure proc_patient_countPatient() sql security invoker
BEGIN            
    SELECT COUNT(*) FROM patient;
END;

