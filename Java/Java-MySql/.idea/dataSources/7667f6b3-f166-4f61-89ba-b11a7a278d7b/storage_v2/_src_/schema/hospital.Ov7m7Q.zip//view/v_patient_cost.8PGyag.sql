create definer = root@localhost view v_patient_cost as
select `p1`.`patientID`                            AS `patientID`,
       `hospital`.`patient`.`patientName`          AS `patientName`,
       sum(`hospital`.`checkitem`.`checkItemCost`) AS `totalcost`
from ((`hospital`.`prescription` `p1` join `hospital`.`checkitem`
       on ((`p1`.`checkItemID` = `hospital`.`checkitem`.`checkItemID`))) join `hospital`.`patient`
      on ((`p1`.`patientID` = `hospital`.`patient`.`patientID`)))
group by `p1`.`patientID`;

-- comment on column v_patient_cost.patientID not supported: 病人编号

-- comment on column v_patient_cost.patientName not supported: 病人姓名

