create definer = root@localhost view v_prescription as
select `pa`.`patientName`  AS `姓名`,
       `pa`.`gender`       AS `性别`,
       `pa`.`birthDate`    AS `年龄`,
       `c`.`checkItemName` AS `检查项目`,
       `pr`.`checkResult`  AS `检查结果`,
       `d`.`depName`       AS `检查科室`,
       `pr`.`examDate`     AS `检查日期`
from (((`hospital`.`prescription` `pr` join `hospital`.`patient` `pa`
        on ((`pr`.`patientID` = `pa`.`patientID`))) join `hospital`.`department` `d`
       on ((`pr`.`depID` = `d`.`depID`))) join `hospital`.`checkitem` `c`
      on ((`pr`.`checkItemID` = `c`.`checkItemID`)));

-- comment on column v_prescription.姓名 not supported: 病人姓名

-- comment on column v_prescription.性别 not supported: 性别

-- comment on column v_prescription.年龄 not supported: 出生日期

-- comment on column v_prescription.检查项目 not supported: 检查项目名称

-- comment on column v_prescription.检查结果 not supported: 检查结果

-- comment on column v_prescription.检查科室 not supported: 科室名称

-- comment on column v_prescription.检查日期 not supported: 检查日期

